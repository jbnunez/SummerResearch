#eig_cluster.py
#clustering based on eigenvalues
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sklearn.cluster as skc
import pandas as pd
import numpy as np

import stock_data as data

X_eigs = data.X_eigs
labels = data.labels




def cluster(k):

    fig = plt.figure(figsize = (8,8))

    ax = fig.add_subplot(111, projection='3d')
    ax.set_xlabel('Eigenvalue 1', fontsize = 15)
    ax.set_ylabel('Eigenvalue 2', fontsize = 15)
    ax.set_zlabel('Eigenvalue 3', fontsize = 15)

    
    ax.set_title('Eigenvalue Clustering, k = '+str(k), fontsize = 20)


    #cluster centers
    kmeans = skc.KMeans(n_clusters=k, random_state=0).fit(X_eigs)
    #finalDf = pd.concat([principalDf, labels], axis = 1)
    #ax.scatter(principalDf['principal component 1'], principalDf['principal component 2'])
    targets = [0, 1, 2, 3, 4]
    colors = ['r', 'b', 'g', 'c', 'm']
    for target, color in zip(targets,colors):
        indicesToKeep = np.where(labels == target)
        ax.scatter(X_eigs[indicesToKeep,0], X_eigs[indicesToKeep,1], 
            X_eigs[indicesToKeep,2], c = color, s = 50)
    for center in kmeans.cluster_centers_:
        ax.scatter(center[0], center[1], center[2], c='k', s=50)
    ax.legend(["Large Loss", "Small Loss", "Minimal Change", 
        "Small Gain", "Large Gain"], loc='best')
    ax.grid()
    plt.savefig("eig_cluster_"+str(k)+".png")
    #plt.show()
    plt.close()

for k in range(2, 21):
    print("Clustering with k = "+str(k))
    cluster(k)



